import {readFileSync} from 'node:fs';
import {DURATION_FRAMES, FPS, SCENES, DURATION_SEC, WIDTH, HEIGHT} from '../src/constants';
import {getState, cameraAt, heliPos, heliVisible, rotorAngle, rotorFrac, PAD, WINDSOCK, STATION, sceneIndex} from '../src/timeline';
import type {V3} from '../src/math';

let fail = 0;
const ok = (c: boolean, m: string) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fail++; };
ok(DURATION_FRAMES === 1952, `1952 frames = 65.07 s @ 30 fps (voiceover 65.04 s)`);
ok(SCENES.length === 8 && SCENES[0].start === 0 && Math.abs(SCENES[7].end - DURATION_SEC) < 1e-9, '8 scenes cover the full timeline');
for (let i = 1; i < SCENES.length; i++) ok(SCENES[i].start === SCENES[i - 1].end, `scene ${i} contiguous`);

// ---- continuity ----
const fin = (o: any): boolean => typeof o === 'number' ? Number.isFinite(o) : typeof o === 'object' && o ? Object.values(o).every(fin) : true;
let allFin = true, maxC = 0, maxT = 0, ang = 0, angBad = 0, maxH = 0;
let pc: any = null, ph: V3 | null = null;
for (let f = 0; f < DURATION_FRAMES; f++) {
  const t = f / FPS, c = cameraAt(t);
  if (!fin(c) || !fin(getState(t)) || !fin(heliPos(t))) allFin = false;
  if (pc) {
    maxC = Math.max(maxC, Math.hypot(c.pos[0] - pc.pos[0], c.pos[1] - pc.pos[1], c.pos[2] - pc.pos[2]));
    maxT = Math.max(maxT, Math.hypot(c.target[0] - pc.target[0], c.target[1] - pc.target[1], c.target[2] - pc.target[2]));
  }
  pc = c;
  const a = rotorAngle(t); if (a < ang - 1e-9) angBad++; ang = a;
  const h = heliPos(t);
  if (ph && heliVisible(t) && heliVisible(t - 1 / FPS)) maxH = Math.max(maxH, Math.hypot(h[0] - ph[0], h[1] - ph[1], h[2] - ph[2]));
  ph = h;
}
ok(allFin, 'all values finite every frame');
ok(angBad === 0, 'rotor angle monotonic');
ok(maxC < 1.0 && maxT < 1.0, `camera steps ok (pos ${maxC.toFixed(2)}, target ${maxT.toFixed(2)} u/frame)`);
ok(maxH < 1.6, `helicopter max step ${maxH.toFixed(2)} u/frame (visible spans)`);
ok(heliPos(46.9)[1] < 1.0 && Math.abs(heliPos(48)[1]) < 1e-6 && rotorFrac(53) === 0, 'touchdown at 47 s, rotors stopped by 53 s');
ok(getState(25.5).rebar.every((v) => v >= 0.99) && getState(21.0).rebar[0] === 0, 'rebar placed 22-25 s');
ok(getState(33).pour === 1 && getState(21).excavate === 1 && getState(36.5).mark === 1, 'construction states complete in order');
ok(getState(5).station === 0 && getState(48).station === 1 && getState(56).hangar === 1, 'station/hangar appear before their scenes');

// ---- camera framing (perspective projection, same maths as three.js) ----
const sub = (a: V3, b: V3): V3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const dot = (a: V3, b: V3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const norm = (a: V3): V3 => { const l = Math.hypot(...a); return [a[0] / l, a[1] / l, a[2] / l]; };
const cross = (a: V3, b: V3): V3 => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
function ndc(t: number, p: V3): [number, number, number] {
  const c = cameraAt(t);
  const fw = norm(sub(c.target, c.pos)), rt = norm(cross(fw, [0, 1, 0])), up = cross(rt, fw);
  const d = sub(p, c.pos), z = dot(d, fw), th = Math.tan((c.fov * Math.PI) / 360);
  return [dot(d, rt) / (z * th * (WIDTH / HEIGHT)), dot(d, up) / (z * th), z];
}
const SAFE_X = 0.92, SAFE_Y = 0.62; // Shorts-safe: 250..1440 px of 1920 after the 115 px shift
const padPts: V3[] = [[-PAD, 0, -PAD], [PAD, 0, -PAD], [-PAD, 0, PAD], [PAD, 0, PAD]];
const heliPts = (t: number): V3[] => { const h = heliPos(t); return [[0, 1.5, 2.8], [0, 1.5, -7], [5.3, 3.3, 0], [-5.3, 3.3, 0]].map((o) => [h[0] + o[0], h[1] + o[1], h[2] + o[2]] as V3); };
const checks: {name: string; a: number; b: number; pts: (t: number) => V3[]; margin?: number}[] = [
  {name: 'S1 helicopter', a: 0.3, b: 8.8, pts: (t) => [heliPos(t)].map((h) => [h[0], h[1] + 1.5, h[2]] as V3)},
  {name: 'S2 pad', a: 12.5, b: 17, pts: () => padPts},
  {name: 'S3 pad', a: 19.5, b: 22.0, pts: () => padPts},
  {name: 'S3 pad end', a: 23.2, b: 26.9, pts: () => [[0, 0, 0]]},
  {name: 'S4 pad centre', a: 27.5, b: 32.8, pts: () => [[0, 0, 0]]},
  {name: 'S5 pad centre', a: 34, b: 37.4, pts: () => [[0, 0, 0]]},
  {name: 'S5 windsock', a: 38.0, b: 38.3, pts: () => [[WINDSOCK[0], 5.5, WINDSOCK[2]]]},
  {name: 'S6 landing', a: 41.5, b: 46.8, pts: (t) => [heliPos(t)].map((h) => [h[0], h[1] + 1.5, h[2]] as V3)},
  {name: 'S7 pump+heli', a: 48.5, b: 55, pts: () => [[STATION[0], 1.2, STATION[2]]]},
  {name: 'S8 helicopter', a: 57.5, b: 64.5, pts: (t) => [[0, 2, heliPos(t)[2]]]},
];
for (const c of checks) {
  let bad = 0, worst = '';
  for (let t = c.a; t <= c.b; t += 1 / FPS)
    for (const p of c.pts(t)) {
      const [x, y, z] = ndc(t, p);
      if (z <= 0.5 || Math.abs(x) > SAFE_X || Math.abs(y) > SAFE_Y) { bad++; worst = `t=${t.toFixed(2)} ndc=(${x.toFixed(2)},${y.toFixed(2)})`; }
    }
  ok(bad === 0, `framing ${c.name}${bad ? ' — ' + bad + ' misses, last ' + worst : ''}`);
}
const env = JSON.parse(readFileSync('src/data/voiceover_envelope.json', 'utf8'));
ok(env.length === DURATION_FRAMES, `voiceover envelope ${env.length} frames`);
ok(sceneIndex(50, SCENES) === 6, 'scene lookup');
process.exit(fail ? 1 : 0);
