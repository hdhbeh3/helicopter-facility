"""Synthesises background music + a synchronised SFX bed (no downloads, no copyright issues)."""
import numpy as np
from scipy import signal
from scipy.io import wavfile
SR = 44100; DUR = 65.5
N = int(DUR * SR); rng = np.random.default_rng(11)
T = np.arange(N) / SR

def band(x, lo, hi, o=2): return signal.sosfilt(signal.butter(o, [lo, hi], 'band', fs=SR, output='sos'), x)
def lp(x, fc, o=2): return signal.sosfilt(signal.butter(o, fc, 'low', fs=SR, output='sos'), x)
def hp(x, fc, o=2): return signal.sosfilt(signal.butter(o, fc, 'high', fs=SR, output='sos'), x)
def sm(t, a, b): return np.clip((t - a) / (b - a), 0, 1) ** 2 * (3 - 2 * np.clip((t - a) / (b - a), 0, 1))
def win(a, b, fi=0.3, fo=0.3): return sm(T, a, a + fi) * (1 - sm(T, b - fo, b))
def noise(): return rng.standard_normal(N)
bed = np.zeros(N)

def add_at(t0, sound, g=1.0):
    i = int(t0 * SR); n = min(len(sound), N - i)
    if n > 0: bed[i:i + n] += sound[:n] * g
def tt(d): return np.arange(int(d * SR)) / SR
def thump(f0=90, d=0.5, k=9): t = tt(d); return np.sin(2 * np.pi * (f0 - 40 * t / d) * t) * np.exp(-t * k)
def ping(f, d=0.35, k=14): t = tt(d); return (np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * f * 2.76 * t)) * np.exp(-t * k)
def burst(d, lo, hi, k): t = tt(d); return band(rng.standard_normal(len(t)), lo, hi) * np.exp(-t * k)

# --- helicopter rotor: blade-pass thump (4 blades) ---
def rotor(a, b, rate=8.9):
    pulse = (0.5 + 0.5 * np.sin(2 * np.pi * rate * T)) ** 3
    return (lp(noise(), 260) * (0.35 + 0.65 * pulse) * 1.6 + lp(noise(), 900) * 0.15) * win(a, b, 0.6, 0.8)
heli_fly = rotor(0, 10.6) * (0.25 + 0.75 * sm(T, 0, 4) * (1 - sm(T, 7.5, 10.6)))
approach = rotor(39.2, 52.8) * (0.1 + 0.9 * sm(T, 39.2, 45.5)) * (1 - 0.8 * sm(T, 47.2, 52.5))
bed += heli_fly + approach
# --- rain ---
bed += hp(lp(noise(), 8000), 1500) * 0.35 * win(9.9, 15.0, 0.6, 1.5) * (1 - 0.6 * sm(T, 13, 15))
# --- excavation: low scrape + dirt chunks ---
bed += lp(noise(), 400) * 0.9 * win(17.4, 20.6, 0.3, 0.4) * (0.5 + 0.5 * np.sin(2 * np.pi * 1.6 * T))
for k in range(5): add_at(17.7 + k * 0.62, burst(0.5, 100, 700, 7), 0.9)
# --- gravel pour ---
bed += band(noise(), 1200, 6000) * 0.5 * win(20.6, 22.0, 0.2, 0.4) * (0.6 + 0.4 * rng.random(N))
# --- rebar placing: metallic pings ---
for i in range(26): add_at(22.0 + i * 0.115, ping(2200 + 300 * (i % 5), 0.25, 18), 0.35)
# --- truck: arrive + idle + drum rumble ---
engine = lp(noise(), 160) * (0.6 + 0.4 * np.sin(2 * np.pi * 21 * T)) + 0.4 * np.sin(2 * np.pi * (46 + 6 * np.sin(T)) * T)
bed += engine * 0.9 * win(22.3, 35.8, 1.5, 1.6)
bed += band(noise(), 80, 300) * 0.5 * win(25, 33, 0.8, 1.0) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.8 * T))
# --- concrete pour: wet slosh ---
bed += lp(noise(), 1400) * (0.4 + 0.3 * np.sin(2 * np.pi * 3.1 * T)) * 0.9 * win(27.4, 31.1, 0.4, 0.6)
# --- finishing swish ---
bed += band(noise(), 600, 3500) * 0.25 * win(31, 33.1, 0.4, 0.4) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.9 * T))
# --- paint spray ---
bed += hp(noise(), 3500) * 0.18 * win(33.6, 36.5, 0.15, 0.3)
# --- cones landing ---
for i in range(12): add_at(35.6 + i * 0.18, thump(160, 0.25, 22) + np.pad(ping(900, 0.15, 40), (0, 11025 - 6615)) * 0.2, 0.7)
# --- windsock flutter / wind ---
bed += band(noise(), 200, 1800) * (0.3 + 0.7 * rng.random(N) ** 4) * 0.4 * win(36.8, 41, 0.5, 0.8)
bed += lp(noise(), 500) * 0.35 * win(34.5, 47, 1.5, 1.5)
# --- touchdown thump + skid settle ---
add_at(46.95, thump(70, 0.9, 5), 1.6); add_at(47.1, ping(600, 0.3, 20), 0.2)
# --- fueling ---
add_at(49.3, thump(140, 0.3, 22) + np.pad(ping(1800, 0.2, 25), (0, 13230 - 8820))[:13230] * 0.4, 1.0)
bed += (lp(noise(), 300) * 0.5 + 0.35 * np.sin(2 * np.pi * 118 * T)) * 0.6 * win(49.5, 55.0, 0.4, 0.5)
bed += band(noise(), 400, 2200) * (0.3 + 0.3 * np.sin(2 * np.pi * 2.3 * T)) * 0.45 * win(49.8, 54.8, 0.4, 0.5)
add_at(55.4, thump(140, 0.3, 22) + np.pad(ping(1500, 0.2, 25), (0, 13230 - 8820))[:13230] * 0.4, 1.0)
for t0 in (49.9, 52.4): add_at(t0, ping(3000, 0.2, 30), 0.25)
# --- hangar doors + tug ---
bed += (band(noise(), 60, 400) * 0.9 + 0.4 * np.sin(2 * np.pi * 52 * T)) * win(56.3, 58.7, 0.3, 0.5) * (0.6 + 0.4 * np.sin(2 * np.pi * 7 * T))
add_at(58.6, thump(100, 0.6, 7), 1.0); add_at(58.65, ping(500, 0.5, 9), 0.3)
bed += (lp(noise(), 240) * 0.6 + 0.5 * np.sin(2 * np.pi * (68 + 4 * np.sin(2 * T)) * T)) * 0.8 * win(56.6, 63.6, 0.6, 1.0)
add_at(63.4, thump(90, 0.4, 12), 0.8)
add_at(64.0, ping(1318, 1.2, 3.5), 0.3); add_at(64.15, ping(1760, 1.2, 3.5), 0.25)

# normalise SFX bed: rms about -28 dBFS (Remotion then applies MIX.sfx and ducking)
bed = bed / (np.sqrt(np.mean(bed ** 2)) + 1e-9) * 10 ** (-28 / 20)
bed = np.tanh(bed * 1.5) / 1.5
bed = bed / max(1, np.max(np.abs(bed)) / 0.9)
# slight stereo width
L = bed; R = np.roll(bed, 40) * 0.98
wavfile.write('public/audio/sfx_bed.wav', SR, (np.clip(np.stack([L, R], 1), -1, 1) * 32767).astype(np.int16))

# --- music: warm pad + soft pluck arpeggio, I-vi-IV-V (C-Am-F-G), 100 bpm ---
beat = 0.6; bar = beat * 4
chords = [[261.63, 329.63, 392.0, 493.88], [220.0, 261.63, 329.63, 392.0], [174.61, 261.63, 349.23, 440.0], [196.0, 246.94, 293.66, 392.0]]
m = np.zeros(N)
for b in range(int(DUR / bar) + 1):
    ch = chords[b % 4]; t0 = b * bar
    i0 = int(t0 * SR); n = min(int(bar * 1.35 * SR), N - i0)
    if n <= 0: break
    tt_ = np.arange(n) / SR
    env = np.minimum(1, tt_ / 0.6) * np.exp(-np.maximum(0, tt_ - bar) * 4)
    pad = sum(np.sin(2 * np.pi * f * tt_) + 0.5 * np.sin(2 * np.pi * f * 1.004 * tt_) + 0.15 * np.sin(2 * np.pi * f * 2 * tt_) for f in ch)
    m[i0:i0 + n] += pad * env * 0.05
    for k in range(8):
        f = ch[[0, 1, 2, 3, 2, 1, 3, 2][k]] * 2; ts = t0 + k * beat / 2
        j = int(ts * SR); d = int(0.5 * SR)
        if j + d < N:
            q = np.arange(d) / SR
            m[j:j + d] += np.sin(2 * np.pi * f * q) * np.exp(-q * 7) * 0.06 * (0.6 + 0.4 * (k % 2 == 0))
m = lp(m, 5000)
m = m / (np.sqrt(np.mean(m ** 2)) + 1e-9) * 10 ** (-27 / 20)
m = m / max(1, np.max(np.abs(m)) / 0.9)
wavfile.write('public/audio/music.wav', SR, (np.clip(np.stack([m, np.roll(m, 90)], 1), -1, 1) * 32767).astype(np.int16))
print('audio written', DUR)
