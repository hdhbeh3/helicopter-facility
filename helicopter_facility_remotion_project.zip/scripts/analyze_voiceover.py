"""Per-frame speech envelope of the supplied voiceover (used to duck music/SFX)."""
import json, subprocess, numpy as np, scipy.io.wavfile as w, os
FPS, FRAMES = 30, 1952
src = 'public/audio/voiceover.mp3'
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', src, '-ar', '16000', '-ac', '1', '/tmp/vo_an.wav'], check=True)
sr, x = w.read('/tmp/vo_an.wav'); x = x.astype(np.float64) / 32768
env = []
for f in range(FRAMES):
    seg = x[max(0, int((f - 0.5) * sr / FPS)): int((f + 1.5) * sr / FPS)]
    env.append(float(np.sqrt(np.mean(seg ** 2))) if len(seg) else 0.0)
env = np.array(env); ref = np.percentile(env, 95) or 1.0
speech = np.clip((env / ref - 0.12) / 0.3, 0, 1)
os.makedirs('src/data', exist_ok=True)
json.dump([round(float(v), 3) for v in speech], open('src/data/voiceover_envelope.json', 'w'))
print(f'duration {len(x)/sr:.3f}s, frames {FRAMES}, speech fraction {np.mean(speech>0.5):.2f}')
