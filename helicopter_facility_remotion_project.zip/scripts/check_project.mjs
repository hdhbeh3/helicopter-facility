// Offline sanity check: syntax of every TS/TSX file, referenced assets, package pins.
import {readFileSync, readdirSync, statSync, existsSync} from 'node:fs';
import {join} from 'node:path';
import {createRequire} from 'node:module';
const require = createRequire(import.meta.url);
let ts;
try { ts = require('typescript'); } catch { ts = require(join(process.env.NODE_PATH || '', 'typescript')); }
let bad = 0;
const walk = (d) => readdirSync(d).flatMap((f) => (statSync(join(d, f)).isDirectory() ? walk(join(d, f)) : [join(d, f)]));
for (const f of [...walk('src'), ...walk('scripts'), 'remotion.config.ts'].filter((f) => /\.(ts|tsx)$/.test(f))) {
  const r = ts.transpileModule(readFileSync(f, 'utf8'), {reportDiagnostics: true, fileName: f, compilerOptions: {jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2020}});
  if (r.diagnostics.length) { bad++; r.diagnostics.forEach((d) => console.log('SYNTAX', f, ts.flattenDiagnosticMessageText(d.messageText, '\n'))); }
}
console.log(bad ? 'FAIL syntax' : 'PASS syntax of all TS/TSX files');
const assets = new Set();
for (const f of walk('src')) for (const m of readFileSync(f, 'utf8').matchAll(/staticFile\('([^']+)'\)/g)) assets.add(m[1]);
for (const a of assets) { const ok = existsSync(join('public', a)); if (!ok) bad++; console.log(ok ? 'PASS' : 'FAIL', 'asset public/' + a); }
const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
const rem = Object.entries({...pkg.dependencies}).filter(([k]) => k.startsWith('remotion') || k.startsWith('@remotion'));
const same = new Set(rem.map(([, v]) => v)).size === 1;
console.log(same ? 'PASS' : 'FAIL', 'all remotion packages pinned to one version:', rem.map(([, v]) => v)[0]);
if (!same) bad++;
process.exit(bad ? 1 : 0);
