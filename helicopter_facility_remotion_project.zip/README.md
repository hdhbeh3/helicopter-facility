# Helicopter Facility — 3D Short (Remotion + three.js)

1080 × 1920 · 30 fps · 9:16 · **1952 frames (65.07 s)** · your voiceover (`public/audio/voiceover.mp3`, 65.04 s) is used untouched.

> ## Status: RENDER UNTESTED
> Built in an offline sandbox: Remotion/three.js/Chromium could not be installed, so **the video has never been rendered or visually inspected** and the 3D code has only been syntax-checked (not type-checked or run).
> Verified: timeline + camera logic and Shorts-safe framing maths (`npm test`), syntax of all TS/TSX, all asset files exist, audio mix levels.
> Expect to look at the first render and adjust camera keys in `src/timeline.ts` (`KEYS`). Fix any TypeScript error the first `npm run typecheck` reports (the workflow stops there).

## Scenes (assumed order — edit `src/constants.ts` + `src/timeline.ts` if your narration differs)
Boundaries sit on pauses measured in your voiceover. The transcript was not available, so topics are assumed:
1 Helicopter flyby (0–9.8 s) · 2 Rainy muddy site (–17.05) · 3 Excavation + rebar (–26.95) · 4 Concrete pour (–33.1) · 5 Safety zone, cones, windsock (–40.75) · 6 Landing + rotor spool-down (–47.15) · 7 Fuel station: hose, pump, underground tank x-ray, extinguisher, grounding (–56.0) · 8 Hangar: dolly + tug tow-in (–65.04).

## Easiest on Android: GitHub Actions (no computer needed)
1. Create a GitHub repo (github.com in Chrome → New repository).
2. Unzip this project (Files app) and upload the **contents** (so `package.json` is at the repo root; include the hidden `.github` folder — if the mobile uploader skips it, create `.github/workflows/render.yml` in the web editor and paste the file).
3. Repo → **Actions → "Render Helicopter Facility Short" → Run workflow**.
4. When it finishes, open the run → **Artifacts → helicopter_final** → `helicopter_final.mp4`. The `smoke_frames` artifact contains two test stills — look at these first if something fails.
Software WebGL rendering is slow (estimate 1–3 h; not measured).

## Locally / Kaggle
```bash
npm install
npm test               # timeline, camera framing, envelope
npm run check          # syntax + asset check
npm run typecheck
npm run start          # Remotion Studio; open "HelicopterSafeZones" to see Shorts UI zones
npm run render         # -> out/helicopter_final.mp4
npm run render:preview # half resolution
npm run still          # one frame -> out/frame.png
```
Kaggle (Internet ON): `!bash scripts/setup_kaggle.sh` then `!npm run render`.

## Audio
`npm run audio` re-creates the speech envelope, the synthesized music + SFX bed (`public/audio/music.wav`, `sfx_bed.wav`; SFX are timed to the animation in `scripts/generate_audio.py`) and checks levels. Music is ~20 dB and SFX ~15 dB below the narration, and both duck while the narrator speaks.

## Files
`src/timeline.ts` (animation, camera) · `src/models.tsx` (all 3D objects) · `src/materials.ts` (procedural textures) · `src/Scene3D.tsx` (camera/lights) · `src/Helicopter.tsx` (compositions, chapter chips, fades) · `scripts/test_timeline.ts` · `.github/workflows/render.yml`
