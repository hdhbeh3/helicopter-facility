// Pure time-based animation data (no three.js) so it can be unit-tested in Node.
import {V3, Keys, pw, smoothedPw, ramp, clamp, lerp} from './math';
import {DURATION_SEC} from './constants';

// ---------------- helicopter flight path ----------------
const HX: Keys = [[0, -46], [3, -24], [6.5, 4], [9.8, 36], [11.5, 70], [39, -6], [41, -4], [43, -1.5], [44.6, 0], [100, 0]];
const HY: Keys = [[0, 15], [3, 13], [6.5, 14], [9.8, 20], [11.5, 26], [39, 24], [41, 17], [43, 10], [44.6, 6.5], [45.6, 4.5], [47.0, 0], [100, 0]];
const HZ: Keys = [[0, -34], [3, -18], [6.5, -2], [9.8, 30], [11.5, 56], [39, 70], [41, 45], [43, 22], [44.6, 8], [45.6, 2], [47, 0], [56.8, 0], [60, -9], [63.2, -21], [100, -21]];
const W = 1.2;
export const heliBase = (t: number): V3 => [smoothedPw(t, HX, W), smoothedPw(t, HY, W), smoothedPw(t, HZ, W)];
export const heliVisible = (t: number) => t < 11 || t > 39.4;
const liftY = (t: number) => 0.2 * ramp(t, 56.4, 57.2); // sits on ground-handling dolly in the hangar scene
export const heliPos = (t: number): V3 => {
  const b = heliBase(t);
  return [b[0], b[1] + liftY(t), b[2]];
};
export const heliYaw = (t: number) => {
  if (t > 12) return Math.PI;
  const a = heliBase(t - 0.1), b = heliBase(t + 0.1);
  return Math.atan2(b[0] - a[0], b[2] - a[2]);
};
export const heliRoll = (t: number) => {
  if (t > 12) return 0;
  const d = heliYaw(t + 0.25) - heliYaw(t - 0.25);
  return clamp(-d * 1.4, -0.35, 0.35);
};
export const heliPitch = (t: number) => {
  const a = heliBase(t - 0.2), b = heliBase(t + 0.2);
  const sp = Math.hypot(b[0] - a[0], b[2] - a[2]) / 0.4;
  return 0.14 * clamp(sp / 9) * (1 - ramp(t, 43.5, 46.5)) + (t > 12 && t < 46 ? 0 : 0);
};
/** rotor speed fraction: full during flight, spools down after touchdown (47 s) */
export const rotorFrac = (t: number) => 1 - ramp(t, 47.3, 52.5);
const OMEGA = 14; // rad/s at full speed (readable at 30 fps)
const STEP = 1 / 600;
const table: number[] = [0];
for (let i = 1; i <= Math.ceil((DURATION_SEC + 1) / STEP); i++) table.push(table[i - 1] + OMEGA * rotorFrac(i * STEP) * STEP);
export const rotorAngle = (t: number) => {
  const x = Math.max(0, t) / STEP, i = Math.floor(x);
  return lerp(table[Math.min(i, table.length - 1)], table[Math.min(i + 1, table.length - 1)], x - i);
};

// ---------------- world state ----------------
export const PAD = 6; // half size of the 12 x 12 m pad
export const STATION: V3 = [11, 0, -2];
export const HANGAR_Z = -20;
export const WINDSOCK: V3 = [9, 0, 7];
export const NUM_CONES = 12;
export const REBAR_N = 13;

export function getState(t: number) {
  const clear = 1 - ramp(t, 10, 10.9) * (1 - ramp(t, 13.2, 16));
  const rebar: number[] = [];
  for (let i = 0; i < REBAR_N * 2; i++) rebar.push(ramp(t, 22 + i * 0.085, 22.7 + i * 0.085));
  const pour = ramp(t, 27.4, 31);
  const hoseOut = ramp(t, 48.4, 49.4) * (1 - ramp(t, 55.2, 55.9));
  return {
    clear,
    rain: clamp((1 - clear) * 1.25),
    wet: ramp(t, 9.8, 12) * (1 - 0.55 * ramp(t, 14, 17.4)),
    excavate: ramp(t, 17.4, 20.4),
    gravel: ramp(t, 20.6, 21.8),
    rebar,
    pour,
    pouring: t > 27.4 && t < 31.1,
    cure: ramp(t, 30.6, 33.0),
    truckX: t < 29 ? lerp(-60, -12.5, ramp(t, 22.3, 25)) : lerp(-12.5, -85, ramp(t, 32.4, 35.6)),
    drum: t * 1.6,
    mark: ramp(t, 33.6, 36.5),
    cones: Array.from({length: NUM_CONES}, (_, i) => ramp(t, 35.4 + i * 0.18, 35.8 + i * 0.18)),
    sock: ramp(t, 36.8, 37.6),
    station: ramp(t, 46.0, 47.3),
    hose: hoseOut,
    fuel: ramp(t, 49.6, 54.8),
    hangar: ramp(t, 54.4, 55.9),
    doors: ramp(t, 56.3, 58.6),
    gear: ramp(t, 56.0, 56.6),
    beacon: Math.sin(t * 7) > 0.2 ? 1 : 0.15,
  };
}
export const sceneIndex = (t: number, scenes: readonly {start: number; end: number}[]) =>
  Math.max(0, scenes.findIndex((s) => t >= s.start && t < s.end));

// ---------------- camera ----------------
export const FOV = 50;
type CK = {t: number; p: V3; l: V3; f?: number};
const add = (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const H = (t: number, o: V3 = [0, 1.8, 0]) => add(heliPos(t), o);
const follow = (t: number, off: V3): CK => ({t, p: add(heliPos(t), off), l: H(t)});

const KEYS: CK[] = [
  // 1 helicopter hero: low orbit following the flyby
  follow(0, [22, -3, 20]), follow(2.5, [17, -1, 26]), follow(5, [4, 3, 28]), follow(7.5, [-12, 5, 24]), follow(9.0, [-20, 6, 18]),
  // 2 rainy muddy site
  {t: 11.6, p: [-26, 12, 40], l: [0, -0.3, 0]}, {t: 17.0, p: [-18, 10, 34], l: [0, -0.5, 0]},
  // 3 excavation + rebar
  {t: 19.0, p: [14, 22, 40], l: [0, -0.6, 0]}, {t: 21.5, p: [0, 36, 12], l: [0, -0.7, 0]}, {t: 22.4, p: [0, 36, 12], l: [0, -0.7, 0]},
  {t: 24.2, p: [0.5, 4.5, 24], l: [0, -0.6, 0]}, {t: 26.5, p: [-10, 8, 18], l: [0, -0.3, 0]},
  // 4 concrete
  {t: 28.5, p: [14, 8, 16], l: [-1, 0, 0]}, {t: 31.0, p: [9, 15, 6], l: [0, 0, 0]}, {t: 33.0, p: [-9, 9, 21], l: [0, 0, 0]},
  // 5 safety zone + windsock
  {t: 35.2, p: [-13, 8, 22], l: [0, 0, 0]}, {t: 37.0, p: [11, 8, 23], l: [0.5, 0, 0]},
  {t: 38.2, p: [2, 3.8, 21], l: [8, 3, 7]}, {t: 40.6, p: [7, 2.4, 30], l: H(40.6)},
  // 6 landing (ground-level, tracks the helicopter)
  {t: 41.0, p: [8, 2.4, 30], l: H(41)}, {t: 43.0, p: [10, 2.6, 30], l: H(43, [0, 1.5, 0])},
  {t: 45.0, p: [13, 3, 29], l: H(45, [0, 1.2, 0])}, {t: 47.2, p: [15, 3.4, 28], l: [0, 1.4, 0]},
  // 7 fuel station
  {t: 48.2, p: [23, 7, 20], l: [5.5, 1, -1]}, {t: 50.2, p: [18, 3.6, 8], l: [9, 1.4, -1.8]},
  {t: 52.5, p: [22, 5, 6], l: [13, -1.0, -2]}, {t: 55.4, p: [14, 6.5, 14], l: [5, 1, -3]},
  // 8 hangar
  {t: 56.6, p: [17, 6.5, 16], l: [0, 2, -9]}, {t: 59.0, p: [15, 4.5, 2], l: [0, 1.8, -11]},
  {t: 61.5, p: [11, 4.2, -7], l: [0, 2, -17]}, {t: 63.6, p: [0, 4, 6], l: [0, 3, -18]}, {t: DURATION_SEC, p: [0, 6.5, 15], l: [0, 3.4, -18]},
];
const comp = (k: (c: CK) => number): Keys => KEYS.map((c) => [c.t, k(c)]);
const CPX = comp((c) => c.p[0]), CPY = comp((c) => c.p[1]), CPZ = comp((c) => c.p[2]);
const CLX = comp((c) => c.l[0]), CLY = comp((c) => c.l[1]), CLZ = comp((c) => c.l[2]);
const CW = 1.0;
export function cameraAt(t: number): {pos: V3; target: V3; fov: number} {
  const g = (k: Keys): number => smoothedPw(t, k, CW);
  return {pos: [g(CPX), g(CPY), g(CPZ)], target: [g(CLX), g(CLY), g(CLZ)], fov: FOV};
}
