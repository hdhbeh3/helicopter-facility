export type V3 = [number, number, number];

export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
/** smootherstep */
export const smooth = (x: number) => {
  const c = clamp(x);
  return c * c * c * (c * (c * 6 - 15) + 10);
};
export const ramp = (t: number, a: number, b: number) => smooth((t - a) / (b - a));

export type Keys = [number, number][];
/** piecewise-linear interpolation over [time,value] keys */
export const pw = (t: number, k: Keys) => {
  if (t <= k[0][0]) return k[0][1];
  for (let i = 1; i < k.length; i++) {
    if (t <= k[i][0]) {
      const [t0, v0] = k[i - 1];
      const [t1, v1] = k[i];
      return v0 + (v1 - v0) * ((t - t0) / (t1 - t0));
    }
  }
  return k[k.length - 1][1];
};
/** piecewise-linear, box-filtered over a window of w seconds -> smooth velocity */
export const smoothedPw = (t: number, k: Keys, w = 1, n = 15) => {
  let s = 0;
  for (let i = 0; i < n; i++) s += pw(t + (i / (n - 1) - 0.5) * w, k);
  return s / n;
};

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
