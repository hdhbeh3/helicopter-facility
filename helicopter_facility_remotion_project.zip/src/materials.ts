import * as THREE from 'three';
import {mulberry32} from './math';

function tex(w: number, h: number, seed: number, draw: (g: CanvasRenderingContext2D, w: number, h: number, r: () => number) => void, rx: number, ry: number) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d')!;
  draw(g, w, h, mulberry32(seed)); // seeded -> identical in every render worker
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(rx, ry);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
const speck = (g: CanvasRenderingContext2D, w: number, h: number, r: () => number, n: number, a: number, dark = false) => {
  for (let i = 0; i < n; i++) {
    const v = dark ? Math.floor(r() * 90) : 120 + Math.floor(r() * 135);
    g.fillStyle = `rgba(${v},${v},${v},${a})`;
    g.fillRect(r() * w, r() * h, 1 + r() * 2, 1 + r() * 2);
  }
};

let cache: ReturnType<typeof build> | null = null;
export const getMats = () => (cache ??= build());

function build() {
  const grass = tex(512, 512, 21, (g, w, h, r) => {
    g.fillStyle = '#5fae3a'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 9000; i++) {
      g.fillStyle = `rgb(${50 + r() * 60},${130 + r() * 80},${30 + r() * 40})`;
      g.fillRect(r() * w, r() * h, 2, 3 + r() * 5);
    }
  }, 90, 90);
  const soil = tex(512, 512, 22, (g, w, h, r) => {
    g.fillStyle = '#8a5a34'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 6000; i++) { g.fillStyle = `rgba(${60 + r() * 80},${35 + r() * 40},${15 + r() * 25},0.5)`; g.fillRect(r() * w, r() * h, 2 + r() * 5, 2 + r() * 4); }
  }, 4, 4);
  const gravel = tex(512, 512, 23, (g, w, h, r) => {
    g.fillStyle = '#9c978d'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 5000; i++) { const v = 90 + r() * 120; g.fillStyle = `rgb(${v},${v - 4},${v - 10})`; g.beginPath(); g.arc(r() * w, r() * h, 2 + r() * 4, 0, 6.3); g.fill(); }
  }, 3, 3);
  const concrete = tex(512, 512, 24, (g, w, h, r) => {
    g.fillStyle = '#b9b8b3'; g.fillRect(0, 0, w, h);
    speck(g, w, h, r, 9000, 0.12); speck(g, w, h, r, 3000, 0.1, true);
  }, 4, 4);
  const asphalt = tex(512, 512, 25, (g, w, h, r) => { g.fillStyle = '#4a4d52'; g.fillRect(0, 0, w, h); speck(g, w, h, r, 9000, 0.18); }, 3, 3);
  const nosmoke = tex(256, 256, 26, (g, w, h) => {
    g.fillStyle = '#fff'; g.fillRect(0, 0, w, h);
    g.strokeStyle = '#d71920'; g.lineWidth = 18; g.beginPath(); g.arc(128, 128, 100, 0, 6.3); g.stroke();
    g.fillStyle = '#222'; g.fillRect(60, 118, 100, 18); g.fillStyle = '#ff7a1a'; g.fillRect(160, 118, 30, 18);
    g.strokeStyle = '#d71920'; g.beginPath(); g.moveTo(58, 58); g.lineTo(198, 198); g.stroke();
  }, 1, 1);
  const hangarFloor = tex(512, 512, 27, (g, w, h, r) => { g.fillStyle = '#9a9ea3'; g.fillRect(0, 0, w, h); speck(g, w, h, r, 6000, 0.12); g.strokeStyle = '#6d7075'; g.lineWidth = 4; g.strokeRect(0, 0, w, h); }, 5, 5);

  const std = (o: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial(o);
  return {
    grass: std({map: grass, roughness: 0.95}),
    soilTop: std({map: soil, roughness: 0.9}),
    topsoil: std({color: '#5a3b22', roughness: 1}),
    subsoil: std({color: '#a7703e', roughness: 1}),
    clay: std({color: '#c98f5a', roughness: 1}),
    gravel: std({map: gravel, roughness: 0.95}),
    concrete: std({map: concrete, roughness: 0.82}),
    asphalt: std({map: asphalt, roughness: 0.9}),
    hangarFloor: std({map: hangarFloor, roughness: 0.7}),
    nosmoke: std({map: nosmoke, roughness: 0.6}),
    rebar: std({color: '#6b4a3a', roughness: 0.5, metalness: 0.7}),
    glass: new THREE.MeshPhysicalMaterial({color: '#1d4e7a', roughness: 0.04, metalness: 0.2, transparent: true, opacity: 0.6, clearcoat: 1}),
    heliRed: new THREE.MeshPhysicalMaterial({color: '#e8321f', roughness: 0.3, metalness: 0.25, clearcoat: 1, clearcoatRoughness: 0.15}),
    heliWhite: new THREE.MeshPhysicalMaterial({color: '#f4f6f8', roughness: 0.35, metalness: 0.2, clearcoat: 0.8}),
    dark: std({color: '#2b2f36', roughness: 0.5, metalness: 0.6}),
    steel: std({color: '#aeb6bf', roughness: 0.35, metalness: 0.85}),
    yellow: std({color: '#ffc107', roughness: 0.5}),
    orange: std({color: '#ff6a1a', roughness: 0.5}),
    white: std({color: '#ffffff', roughness: 0.6}),
    red: std({color: '#d62828', roughness: 0.4}),
    wall: std({color: '#dfe6ec', roughness: 0.55, metalness: 0.3}),
    roof: std({color: '#3f78c9', roughness: 0.4, metalness: 0.5}),
  };
}
