import React, {useMemo} from 'react';
import * as THREE from 'three';
import {getMats} from './materials';
import {V3, lerp, mulberry32, ramp, clamp} from './math';
import {PAD, STATION, HANGAR_Z, WINDSOCK, NUM_CONES, REBAR_N, heliPos, heliYaw, heliRoll, heliPitch, heliVisible, rotorAngle, rotorFrac, getState} from './timeline';

type S = ReturnType<typeof getState>;
type P = {p?: V3; r?: V3; s?: V3; m?: THREE.Material; color?: string; rough?: number; metal?: number; emis?: string; ei?: number; shadow?: boolean; vis?: boolean; opacity?: number; children?: React.ReactNode};
const Mat: React.FC<P> = ({m, color = '#fff', rough = 0.5, metal = 0, emis, ei = 1, opacity}) =>
  m ? <primitive object={m} attach="material" /> : (
    <meshStandardMaterial color={color} roughness={rough} metalness={metal} emissive={emis ?? '#000'} emissiveIntensity={emis ? ei : 0} transparent={opacity !== undefined} opacity={opacity ?? 1} />
  );
const wrap = (geo: (a: any) => React.ReactNode) => (props: P & {a: any}) => (
  <mesh position={props.p} rotation={props.r} scale={props.s} castShadow={props.shadow !== false} receiveShadow visible={props.vis !== false}>
    {geo(props.a)}<Mat {...props} />{props.children}
  </mesh>
);
const Box = wrap((a) => <boxGeometry args={a} />);
const Cyl = wrap((a) => <cylinderGeometry args={a} />);
const Sph = wrap((a) => <sphereGeometry args={[a[0], a[1] ?? 24, a[2] ?? 16]} />);

// ---------------- environment ----------------
export const Sky: React.FC<{clear: number}> = ({clear}) => {
  const geo = useMemo(() => {
    const g = new THREE.SphereGeometry(900, 24, 16);
    const pos = g.attributes.position, col: number[] = [];
    const top = new THREE.Color('#2f7de1'), hor = new THREE.Color('#bfe3ff');
    for (let i = 0; i < pos.count; i++) { const h = clamp(pos.getY(i) / 500); const c = hor.clone().lerp(top, Math.pow(h, 0.6)); col.push(c.r, c.g, c.b); }
    g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    return g;
  }, []);
  const tint = new THREE.Color('#7f8a96').lerp(new THREE.Color('#ffffff'), clear);
  return <mesh geometry={geo}><meshBasicMaterial vertexColors side={THREE.BackSide} color={tint} fog={false} /></mesh>;
};

export const Clouds: React.FC<{t: number; clear: number}> = ({t, clear}) => {
  const list = useMemo(() => { const r = mulberry32(5); return Array.from({length: 9}, () => ({x: (r() - 0.5) * 360, y: 55 + r() * 30, z: -60 - r() * 160, s: 8 + r() * 10})); }, []);
  return <>{list.map((c, i) => {
    const x = ((c.x + t * 1.6 + 200) % 400) - 200;
    const gray = lerp(0.5, 1, clear);
    return <group key={i} position={[x, c.y, c.z]}>{[[0, 0, 0, 1], [1.1, -0.2, 0.2, 0.8], [-1.1, -0.15, 0, 0.85], [0.4, 0.4, -0.3, 0.7]].map((o, j) => (
      <Sph key={j} p={[o[0] * c.s, o[1] * c.s, o[2] * c.s]} s={[1.6, 0.8, 1]} a={[c.s * o[3]]} color={`rgb(${255 * gray | 0},${255 * gray | 0},${255 * gray | 0})`} rough={1} shadow={false} />
    ))}</group>;
  })}</>;
};

export const Rain: React.FC<{t: number; amt: number}> = ({t, amt}) => {
  const drops = useMemo(() => { const r = mulberry32(9); return Array.from({length: 160}, () => ({x: (r() - 0.5) * 70, z: (r() - 0.5) * 70, o: r() * 30})); }, []);
  if (amt < 0.02) return null;
  return <>{drops.map((d, i) => <mesh key={i} position={[d.x, 30 - ((t * 26 + d.o) % 30), d.z]} visible={i < amt * 160}>
    <cylinderGeometry args={[0.02, 0.02, 1.4, 4]} /><meshBasicMaterial color="#cfe6ff" transparent opacity={0.55} /></mesh>)}</>;
};

const Strip: React.FC<{cx: number; cz: number; w: number; d: number}> = ({cx, cz, w, d}) => {
  const M = getMats();
  const layers: [number, number, THREE.Material][] = [[0.12, 0, M.grass], [0.5, 0.12, M.topsoil], [0.6, 0.62, M.subsoil], [0.5, 1.22, M.clay]];
  return <>{layers.map(([h, off, m], i) => <Box key={i} p={[cx, -off - h / 2, cz]} a={[w, h, d]} m={m} shadow={false} />)}</>;
};
const BIG = 260;
export const Ground: React.FC<{s: S}> = ({s}) => {
  const M = getMats();
  const depth = 0.9 * s.excavate;
  const wet = s.wet;
  const topCol = new THREE.Color('#d9b88a').lerp(new THREE.Color('#5b3d27'), wet);
  const ringGeo = useMemo(() => {
    const sh = new THREE.Shape(); sh.absarc(0, 0, 10.5, 0, Math.PI * 2, false);
    const h = new THREE.Path(); h.moveTo(-PAD, -PAD); h.lineTo(-PAD, PAD); h.lineTo(PAD, PAD); h.lineTo(PAD, -PAD); h.lineTo(-PAD, -PAD);
    sh.holes.push(h); return new THREE.ShapeGeometry(sh, 48);
  }, []);
  const r = mulberry32(3);
  const puddles = useMemo(() => Array.from({length: 7}, (_, i) => { const a = i * 0.9 + 0.3, d = 3 + (i % 3) * 2.4; return {x: Math.cos(a) * d, z: Math.sin(a) * d, s: 1 + (i % 4) * 0.45}; }), []);
  void r;
  return (
    <group>
      <Box p={[0, -1.75, 0]} a={[BIG * 2, 0.1, BIG * 2]} color="#4a3220" shadow={false} />
      <Strip cx={-(PAD + BIG) / 2} cz={0} w={BIG - PAD} d={BIG * 2} />
      <Strip cx={(PAD + BIG) / 2} cz={0} w={BIG - PAD} d={BIG * 2} />
      <Strip cx={0} cz={(PAD + BIG) / 2} w={PAD * 2} d={BIG - PAD} />
      <Strip cx={0} cz={-(PAD + BIG) / 2} w={PAD * 2} d={BIG - PAD} />
      {/* disturbed ground ring around the pad (appears with the rain/mud) */}
      <mesh geometry={ringGeo} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]} receiveShadow visible={wet > 0.01}>
        <meshStandardMaterial map={M.soilTop.map} color={topCol} roughness={lerp(0.9, 0.3, wet)} transparent opacity={clamp(wet * 1.4)} polygonOffset polygonOffsetFactor={-2} />
      </mesh>
      {/* the pad plug: bare soil that sinks during excavation */}
      <Box p={[0, -depth - 0.86, 0]} a={[PAD * 2 - 0.04, 1.72, PAD * 2 - 0.04]} m={M.topsoil} />
      <mesh position={[0, -depth + 0.001, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[PAD * 2 - 0.04, PAD * 2 - 0.04]} />
        <meshStandardMaterial map={M.soilTop.map} color={topCol} roughness={lerp(0.9, 0.3, wet)} />
      </mesh>
      {puddles.map((p, i) => <mesh key={i} position={[p.x, -depth * (Math.abs(p.x) < PAD && Math.abs(p.z) < PAD ? 1 : 0) + 0.03, p.z]} rotation={[-Math.PI / 2, 0, 0]} scale={[p.s * 1.4, p.s, 1]} visible={wet > 0.05 && s.excavate < 0.2 + 0.01 * i}>
        <circleGeometry args={[1, 24]} /><meshStandardMaterial color="#6a4a32" roughness={0.05} metalness={0.3} transparent opacity={0.85 * wet} />
      </mesh>)}
    </group>
  );
};

// ---------------- landing pad construction ----------------
export const PadWork: React.FC<{s: S}> = ({s}) => {
  const M = getMats();
  const top = -0.9 * s.excavate;
  const gH = 0.3 * s.gravel;
  const cH = 0.6 * s.pour + 0.02 * s.cure;
  const L = PAD * 2 - 0.3;
  const wetC = new THREE.Color('#6f6f6c').lerp(new THREE.Color('#ffffff'), s.cure);
  const bars: React.ReactNode[] = [];
  for (let i = 0; i < REBAR_N; i++) {
    const c = -PAD + 0.6 + (i * (PAD * 2 - 1.2)) / (REBAR_N - 1);
    const px = s.rebar[i], pz = s.rebar[REBAR_N + i];
    bars.push(<mesh key={'x' + i} position={[-L / 2 + (L * px) / 2, -0.48, c]} rotation={[0, 0, Math.PI / 2]} scale={[1, Math.max(px, 0.001), 1]} visible={px > 0.001 && cH < 0.12} castShadow>
      <cylinderGeometry args={[0.035, 0.035, L, 8]} /><primitive object={M.rebar} attach="material" /></mesh>);
    bars.push(<mesh key={'z' + i} position={[c, -0.42, -L / 2 + (L * pz) / 2]} rotation={[Math.PI / 2, 0, 0]} scale={[1, Math.max(pz, 0.001), 1]} visible={pz > 0.001 && cH < 0.2} castShadow>
      <cylinderGeometry args={[0.035, 0.035, L, 8]} /><primitive object={M.rebar} attach="material" /></mesh>);
  }
  return (
    <group visible={s.excavate > 0.98}>
      <Box p={[0, top + 0.001 + gH / 2 + 0.0, 0]} a={[L + 0.2, Math.max(gH, 0.001), L + 0.2]} m={M.gravel} vis={gH > 0.002} />
      {bars}
      <Box p={[0, -0.6 + cH / 2, 0]} a={[PAD * 2 - 0.05, Math.max(cH, 0.001), PAD * 2 - 0.05]} color={'#' + wetC.getHexString()} m={undefined} rough={lerp(0.25, 0.85, s.cure)} vis={cH > 0.002} />
      {/* cured concrete texture overlay fades in on top */}
      <mesh position={[0, 0.021, 0]} rotation={[-Math.PI / 2, 0, 0]} visible={s.cure > 0.02} receiveShadow>
        <planeGeometry args={[PAD * 2 - 0.06, PAD * 2 - 0.06]} /><meshStandardMaterial map={M.concrete.map} roughness={0.85} transparent opacity={s.cure} />
      </mesh>
    </group>
  );
};

export const MixerTruck: React.FC<{s: S}> = ({s}) => {
  const M = getMats();
  const moving = s.truckX < -12.4 || s.truckX > -12.6;
  const flow = s.pouring ? 1 : 0;
  return (
    <group position={[s.truckX, 0, 0]} rotation={[0, -Math.PI / 2, 0]} visible={s.truckX > -84 && s.truckX < 59}>
      <Box p={[0, 0.9, 0]} a={[2.5, 0.5, 8]} color="#3a3f47" metal={0.5} />
      <Box p={[0, 2.0, 3.2]} a={[2.4, 2.0, 1.9]} color="#ffb300" rough={0.35} />
      <Box p={[0, 2.3, 4.15]} a={[2.0, 0.9, 0.05]} m={M.glass} />
      {[[-1.2, 3.2], [1.2, 3.2], [-1.2, -2.2], [1.2, -2.2], [-1.2, -3.6], [1.2, -3.6]].map((w, i) => (
        <Cyl key={i} p={[w[0], 0.55, w[1]]} r={[0, 0, Math.PI / 2]} a={[0.55, 0.55, 0.4, 20]} color="#15171a" rough={0.9} />
      ))}
      <group position={[0, 2.5, -1.2]} rotation={[-0.25, 0, 0]}>
        <group rotation={[0, 0, s.drum]}>
          {/* drum with spiral stripes: rotating cone-cylinder */}
          <mesh castShadow rotation={[Math.PI / 2, 0, 0]}><cylinderGeometry args={[1.35, 0.7, 4.8, 24]} /><meshStandardMaterial color="#ff6a1a" roughness={0.35} metalness={0.2} /></mesh>
          {[0, 1, 2].map((k) => <Box key={k} p={[Math.cos(k * 2.09) * 1.38, Math.sin(k * 2.09) * 1.38, 0.4]} r={[0, 0, k * 2.09]} a={[0.08, 0.05, 4.2]} color="#fff" />)}
        </group>
      </group>
      <Box p={[0, 3.8, -3.8]} r={[0.12, 0, 0]} a={[0.5, 0.4, 2.4]} color="#c9ced6" metal={0.6} />
      {/* discharge boom toward the pad (truck faces +z locally; rotated so the boom points +x in world after yaw) */}
      <group position={[0, 3.9, -4.9]}>
        <Box p={[0, 0, -2.2]} a={[0.5, 0.4, 4.6]} color="#c9ced6" metal={0.6} />
      </group>
      {flow > 0 && !moving && <Cyl p={[0, (3.7 + (-0.6 + 0.6 * s.pour)) / 2, -9.5]} a={[0.14, 0.14, 3.7 - (-0.6 + 0.6 * s.pour), 10]} color="#8a8985" rough={0.2} />}
    </group>
  );
};

// ---------------- safety zone ----------------
export const SafetyZone: React.FC<{t: number; s: S}> = ({t, s}) => {
  const M = getMats();
  const ringGeo = useMemo(() => new THREE.RingGeometry(9.3, 9.7, 96), []);
  const circleGeo = useMemo(() => new THREE.RingGeometry(3.6, 4.0, 64), []);
  return (
    <group visible={s.mark > 0.001}>
      {/* painted H marking */}
      <mesh geometry={circleGeo} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.04, 0]} scale={[s.mark, s.mark, s.mark]}><meshStandardMaterial color="#fff" roughness={0.6} /></mesh>
      <group position={[0, 0.045, 0]} scale={[s.mark, 1, s.mark]}>
        <Box p={[-1, 0, 0]} a={[0.45, 0.02, 3.4]} m={M.white} shadow={false} />
        <Box p={[1, 0, 0]} a={[0.45, 0.02, 3.4]} m={M.white} shadow={false} />
        <Box p={[0, 0, 0]} a={[1.6, 0.02, 0.45]} m={M.white} shadow={false} />
        {[[-1, -1], [1, -1], [-1, 1], [1, 1]].map((c, i) => <Box key={i} p={[c[0] * 5.6, 0.03, c[1] * 5.6]} a={[0.3, 0.02, 0.9]} m={M.yellow} shadow={false} />)}
        <Box p={[0, 0.04, PAD - 0.15]} a={[PAD * 2 - 0.3, 0.02, 0.3]} m={M.yellow} shadow={false} />
        <Box p={[0, 0.04, -PAD + 0.15]} a={[PAD * 2 - 0.3, 0.02, 0.3]} m={M.yellow} shadow={false} />
        <Box p={[PAD - 0.15, 0.04, 0]} a={[0.3, 0.02, PAD * 2 - 0.3]} m={M.yellow} shadow={false} />
        <Box p={[-PAD + 0.15, 0.04, 0]} a={[0.3, 0.02, PAD * 2 - 0.3]} m={M.yellow} shadow={false} />
      </group>
      {/* safety-zone ring on the grass */}
      <mesh geometry={ringGeo} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.05, 0]} scale={[s.mark, s.mark, s.mark]}>
        <meshStandardMaterial color="#ffd400" emissive="#ffb300" emissiveIntensity={0.5 + 0.2 * Math.sin(t * 4)} roughness={0.6} />
      </mesh>
      {s.cones.map((c, i) => {
        const a = (i / NUM_CONES) * Math.PI * 2 + 0.26, bounce = (1 - c) * 4 + Math.abs(Math.sin(c * 9)) * 0.08 * (1 - c);
        return <group key={i} position={[Math.cos(a) * 9.5, 0 + (c > 0.001 ? bounce : -5), Math.sin(a) * 9.5]}>
          <Cyl p={[0, 0.4, 0]} a={[0.06, 0.26, 0.8, 16]} m={M.orange} />
          <Cyl p={[0, 0.5, 0]} a={[0.12, 0.17, 0.16, 16]} m={M.white} shadow={false} />
          <Box p={[0, 0.02, 0]} a={[0.6, 0.04, 0.6]} color="#222" />
        </group>;
      })}
      {/* beacons on the pad corners */}
      {[[-1, -1], [1, -1], [-1, 1], [1, 1]].map((c, i) => <Sph key={i} p={[c[0] * (PAD - 0.5), 0.12, c[1] * (PAD - 0.5)]} s={[1, 0.6, 1]} a={[0.16]} color="#ffb300" emis="#ffb300" ei={2 * (s.beacon * s.mark)} shadow={false} />)}
    </group>
  );
};

export const Windsock: React.FC<{t: number; s: S}> = ({t, s}) => {
  const M = getMats();
  const wind = 0.75 + 0.2 * Math.sin(t * 1.3);
  const segs = [0, 1, 2, 3, 4];
  return (
    <group position={[WINDSOCK[0], 0, WINDSOCK[2]]} scale={[1, Math.max(s.sock, 0.001), 1]} visible={s.sock > 0.001}>
      <Cyl p={[0, 3, 0]} a={[0.08, 0.14, 6, 12]} m={M.steel} />
      <Cyl p={[0, 0.15, 0]} a={[0.45, 0.5, 0.3, 16]} m={M.concrete} />
      <group position={[0, 6.05, 0]} rotation={[0, 0.5 + 0.12 * Math.sin(t * 0.9), 0]}>
        <Box p={[0.35, 0, 0]} a={[0.7, 0.07, 0.07]} m={M.steel} />
        <mesh position={[0.7, 0, 0]} rotation={[0, 0, Math.PI / 2]}><torusGeometry args={[0.38, 0.03, 8, 20]} /><primitive object={M.steel} attach="material" /></mesh>
        <group position={[0.7, 0, 0]}>
          {segs.map((i) => {
            const droop = (1 - wind) * 0.9 * i * 0.25, fl = Math.sin(t * 7 + i * 1.3) * 0.05 * i * wind;
            const r0 = 0.38 * (1 - i * 0.14), r1 = 0.38 * (1 - (i + 1) * 0.14);
            return <mesh key={i} position={[0.32 + i * 0.64, -droop + fl, 0]} rotation={[0, 0, -Math.PI / 2]} castShadow>
              <cylinderGeometry args={[r1, r0, 0.64, 16, 1, true]} /><meshStandardMaterial color={i % 2 ? '#ffffff' : '#ff5a1f'} side={THREE.DoubleSide} roughness={0.8} />
            </mesh>;
          })}
        </group>
      </group>
    </group>
  );
};

// ---------------- helicopter ----------------
const Rotor: React.FC<{n: number; len: number; w: number; ang: number; frac: number; disc: number}> = ({n, len, w, ang, frac, disc}) => {
  const M = getMats();
  return (
    <group rotation={[0, ang, 0]}>
      {Array.from({length: n}, (_, k) => (
        <group key={k} rotation={[0, (k * Math.PI * 2) / n, 0]}>
          <Box p={[len / 2 + 0.25, 0, 0]} a={[len, 0.045, w]} color="#25282d" rough={0.4} />
          <Box p={[len + 0.05, 0.002, 0]} a={[len * 0.1, 0.047, w * 1.02]} color="#ffc107" />
        </group>
      ))}
      <mesh rotation={[-Math.PI / 2, 0, 0]} visible={frac > 0.15}><circleGeometry args={[len + 0.3, 40]} />
        <meshBasicMaterial color="#cdd5dd" transparent opacity={disc * frac} side={THREE.DoubleSide} depthWrite={false} /></mesh>
      <Cyl p={[0, 0, 0]} a={[0.22, 0.22, 0.14, 16]} m={M.dark} />
    </group>
  );
};

export const Helicopter: React.FC<{t: number}> = ({t}) => {
  const M = getMats();
  const pos = heliPos(t), frac = rotorFrac(t), ang = rotorAngle(t);
  const nav = Math.sin(t * 8) > 0.3 ? 1 : 0.1;
  return (
    <group position={pos} rotation={new THREE.Euler(heliPitch(t), heliYaw(t), heliRoll(t), 'YXZ')} visible={heliVisible(t)}>
      <Sph p={[0, 1.55, 0]} s={[1.1, 1.2, 2.7]} a={[1]} m={M.heliRed} />
      <Sph p={[0, 1.05, 0.2]} s={[1.0, 0.7, 2.3]} a={[1]} m={M.heliWhite} />
      <Sph p={[0, 1.85, 1.35]} s={[0.98, 0.85, 1.35]} a={[1]} m={M.glass} shadow={false} />
      <Sph p={[0, 2.75, -0.2]} s={[0.85, 0.5, 1.5]} a={[1]} m={M.dark} />
      <Cyl p={[0, 1.9, -4.3]} r={[-Math.PI / 2, 0, 0]} a={[0.14, 0.4, 5.6, 16]} m={M.heliRed} />
      <Box p={[0, 2.35, -6.9]} r={[-0.25, 0, 0]} a={[0.1, 1.5, 0.9]} m={M.heliWhite} />
      <Box p={[0, 1.8, -6.3]} a={[1.9, 0.06, 0.5]} m={M.heliRed} />
      <Cyl p={[0, 3.05, 0]} a={[0.1, 0.1, 0.6, 12]} m={M.steel} />
      <group position={[0, 3.35, 0]}><Rotor n={4} len={5.0} w={0.32} ang={ang} frac={frac} disc={0.16} /></group>
      <group position={[0.2, 2.45, -6.95]} rotation={[0, 0, Math.PI / 2]}><group rotation={[0, ang * 3.2, 0]}>
        <Rotor n={2} len={0.62} w={0.12} ang={0} frac={frac} disc={0.1} />
      </group></group>
      {/* skids */}
      {[-1.15, 1.15].map((x, i) => <React.Fragment key={i}>
        <Cyl p={[x, 0.07, 0]} r={[Math.PI / 2, 0, 0]} a={[0.055, 0.055, 3.6, 12]} m={M.dark} />
        <Cyl p={[x, 0.55, 0.9]} r={[0, 0, x > 0 ? -0.18 : 0.18]} a={[0.04, 0.04, 1.0, 8]} m={M.dark} />
        <Cyl p={[x, 0.55, -0.9]} r={[0, 0, x > 0 ? -0.18 : 0.18]} a={[0.04, 0.04, 1.0, 8]} m={M.dark} />
      </React.Fragment>)}
      <Cyl p={[0, 1.05, 0.9]} r={[0, 0, Math.PI / 2]} a={[0.035, 0.035, 2.2, 8]} m={M.dark} />
      <Cyl p={[0, 1.05, -0.9]} r={[0, 0, Math.PI / 2]} a={[0.035, 0.035, 2.2, 8]} m={M.dark} />
      {/* fuel filler port (starboard) + lights */}
      <Cyl p={[-1.08, 1.3, 0.35]} r={[0, 0, Math.PI / 2]} a={[0.1, 0.1, 0.06, 16]} color="#d4af37" metal={0.9} rough={0.3} />
      <Sph p={[0, 0.85, 2.2]} a={[0.12]} color="#fff" emis="#fff6d0" ei={3} shadow={false} />
      <Sph p={[-1.1, 1.55, -0.2]} a={[0.1]} color="#2bd45a" emis="#2bd45a" ei={3 * nav} shadow={false} />
      <Sph p={[1.1, 1.55, -0.2]} a={[0.1]} color="#ff2b2b" emis="#ff2b2b" ei={3 * nav} shadow={false} />
      <Sph p={[0, 2.85, -7.1]} a={[0.09]} color="#fff" emis="#ffffff" ei={4 * nav} shadow={false} />
    </group>
  );
};

// ---------------- fuel station ----------------
const tubeGeo = (pts: V3[], r: number) => new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(...p))), 48, r, 8, false);
export const FuelStation: React.FC<{t: number; s: S}> = ({t, s}) => {
  const M = getMats();
  const [sx, , sz] = STATION;
  const rise = (1 - s.station) * -9;
  const hose = useMemo(() => tubeGeo([[sx - 0.2, 1.3, sz + 0.35], [sx - 2, 0.15, sz + 0.5], [sx - 5, 0.1, sz + 0.1], [2.2, 0.35, -0.1], [1.12, 1.25, -0.35]], 0.045), [sx, sz]);
  const total = hose.index!.count;
  hose.setDrawRange(0, Math.floor((total / 3) * s.hose) * 3);
  const ground = useMemo(() => tubeGeo([[1.1, 0.07, 0.9], [2.0, 0.1, 2.2], [3.2, 0.1, 2.6]], 0.02), []);
  const tx = 14.8, ty = -1.25;
  const lvl = 1 - 0.35 * s.fuel;
  const xray = {depthTest: false, transparent: true} as const;
  return (
    <group position={[0, rise, 0]} visible={s.station > 0.001}>
      <Box p={[13, 0.03, sz]} a={[8, 0.06, 7]} m={M.asphalt} shadow={false} />
      {/* pump */}
      <group position={[sx, 0, sz]}>
        <Box p={[0, 0.1, 0]} a={[1.5, 0.2, 1.1]} m={M.concrete} />
        <Box p={[0, 1.1, 0]} a={[1.0, 1.9, 0.6]} color="#f2f4f6" rough={0.3} />
        <Box p={[0, 1.95, 0]} a={[1.1, 0.25, 0.7]} color="#e8321f" />
        <Box p={[-0.1, 1.45, 0.31]} a={[0.7, 0.3, 0.02]} color="#0b1d12" rough={0.1} />
        <Box p={[-0.1 - 0.35 + 0.35 * s.fuel, 1.45, 0.325]} a={[0.7 * Math.max(s.fuel, 0.001), 0.2, 0.02]} color="#38ff7a" emis="#38ff7a" ei={1.6} shadow={false} />
        <Cyl p={[0.2, 0.95, 0.32]} r={[Math.PI / 2, 0, 0]} a={[0.2, 0.2, 0.03, 24]} color="#101418" rough={0.2} />
        <mesh position={[0.2, 0.95, 0.34]}><ringGeometry args={[0.07, 0.16, 32, 1, Math.PI / 2, -Math.PI * 1.7 * Math.max(s.fuel, 0.01)]} /><meshBasicMaterial color="#ffb300" side={THREE.DoubleSide} /></mesh>
        <Box p={[0.62, 0.9, 0]} r={[0, 0, -0.25]} a={[0.12, 0.5, 0.2]} color="#222" />
      </group>
      {/* hose runs from pump to the helicopter fuel port */}
      <mesh geometry={hose} castShadow><meshStandardMaterial color="#1b1d21" roughness={0.6} /></mesh>
      {/* grounding rod + cable to the helicopter */}
      <Cyl p={[3.2, 0.5, 2.6]} a={[0.03, 0.03, 1.0, 8]} m={M.steel} />
      <mesh geometry={ground} visible={s.station > 0.9}><meshStandardMaterial color="#2bb24c" roughness={0.5} /></mesh>
      {/* safety equipment */}
      <group position={[sx + 1.4, 0, sz + 1.6]}>
        <Cyl p={[0, 0.32, 0]} a={[0.1, 0.1, 0.6, 16]} m={M.red} />
        <Cyl p={[0, 0.66, 0]} a={[0.04, 0.04, 0.08, 8]} color="#111" />
        <Box p={[0.12, 0.6, 0]} a={[0.12, 0.03, 0.03]} color="#111" />
        <Box p={[0, 0.02, 0]} a={[0.35, 0.04, 0.35]} color="#d62828" />
      </group>
      <group position={[sx - 0.9, 0, sz - 0.9]}>
        <Cyl p={[0, 0.8, 0]} a={[0.04, 0.04, 1.6, 8]} m={M.steel} />
        <Cyl p={[0, 1.65, 0]} a={[0.16, 0.16, 0.18, 16]} color="#d62828" emis="#ff1a1a" ei={1.2} />
      </group>
      <group position={[sx + 3.2, 0, sz + 2.8]}>
        <Cyl p={[0, 0.9, 0]} a={[0.04, 0.04, 1.8, 8]} m={M.steel} />
        <mesh position={[0, 1.9, 0]} castShadow><boxGeometry args={[0.8, 0.8, 0.04]} /><primitive object={M.nosmoke} attach="material" /></mesh>
      </group>
      {[[sx - 1.8, sz + 2.6], [sx + 3.8, sz + 2.6], [sx + 3.8, sz - 2.6]].map((b, i) => <group key={i} position={[b[0], 0, b[1]]}>
        <Cyl p={[0, 0.45, 0]} a={[0.12, 0.12, 0.9, 16]} m={M.yellow} />
        <Cyl p={[0, 0.55, 0]} a={[0.125, 0.125, 0.12, 16]} color="#222" />
      </group>)}
      {/* underground tank: x-ray view through the ground */}
      <mesh position={[tx - 0.7, 0.07, sz]} rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[7, 6]} />
        <meshBasicMaterial color="#5a3b22" opacity={0.28 * s.station} {...xray} depthWrite={false} /></mesh>
      <group renderOrder={20}>
        <mesh position={[tx, ty, sz]} rotation={[Math.PI / 2, 0, 0]} renderOrder={21}><cylinderGeometry args={[1.0, 1.0, 5, 28]} /><meshStandardMaterial color="#c8d0d8" metalness={0.8} roughness={0.25} opacity={0.5} {...xray} /></mesh>
        <mesh position={[tx, ty - 1 * (1 - lvl) * 0.9, sz]} rotation={[Math.PI / 2, 0, 0]} scale={[lvl, 1, lvl]} renderOrder={22}><cylinderGeometry args={[0.85, 0.85, 4.8, 28]} /><meshStandardMaterial color="#ffb300" emissive="#ff8a00" emissiveIntensity={0.7} opacity={0.9} {...xray} /></mesh>
        <mesh position={[(tx + sx) / 2 - 0.2, ty, sz]} rotation={[0, 0, Math.PI / 2]} renderOrder={21}><cylinderGeometry args={[0.07, 0.07, tx - sx - 1, 10]} /><meshStandardMaterial color="#e8321f" opacity={0.9} {...xray} /></mesh>
        <mesh position={[sx - 0.55, ty / 2 + 0.2, sz]} renderOrder={21}><cylinderGeometry args={[0.07, 0.07, -ty + 0.4, 10]} /><meshStandardMaterial color="#e8321f" opacity={0.9} {...xray} /></mesh>
        {[0, 1, 2, 3].map((i) => { const u = ((t * 0.9 + i / 4) % 1) * s.fuel; const on = s.fuel > 0.01 && s.fuel < 1; const px = lerp(tx - 1, sx - 0.55, Math.min(1, u * 2)); const py = u < 0.5 ? ty : lerp(ty, 0.6, (u - 0.5) * 2);
          return <mesh key={i} position={[px, py, sz]} visible={on} renderOrder={23}><sphereGeometry args={[0.13, 10, 8]} /><meshBasicMaterial color="#ffd54a" {...xray} /></mesh>; })}
      </group>
    </group>
  );
};

// ---------------- hangar + ground handling ----------------
const archShape = (w: number, h: number) => { const s = new THREE.Shape(); s.moveTo(0, 0); s.lineTo(w, 0); s.absellipse(0, 0, w, h, 0, Math.PI / 2, false); s.lineTo(0, 0); return s; };
export const Hangar: React.FC<{s: S; t: number}> = ({s, t}) => {
  const M = getMats();
  const W2 = 11, D = 18, Hh = 8.2, z0 = HANGAR_Z;
  const rise = (1 - s.hangar) * -16;
  const shape = useMemo(() => new THREE.ShapeGeometry(archShape(W2, Hh), 32), []);
  const hz = heliPos(t)[2];
  return (
    <group position={[0, rise, z0]} visible={s.hangar > 0.001}>
      <Box p={[0, 0.06, 0]} a={[W2 * 2 + 2, 0.12, D + 8]} m={M.hangarFloor} shadow={false} />
      <group scale={[1, Hh / W2, 1]}>
        <mesh rotation={[Math.PI / 2, 0, 0]} castShadow receiveShadow>
          <cylinderGeometry args={[W2, W2, D, 40, 1, true, Math.PI / 2, Math.PI]} />
          <meshStandardMaterial color="#3f78c9" roughness={0.4} metalness={0.5} side={THREE.DoubleSide} />
        </mesh>
      </group>
      <mesh position={[0, 0, -D / 2]} geometry={shape} receiveShadow><meshStandardMaterial color="#dfe6ec" roughness={0.5} side={THREE.DoubleSide} /></mesh>
      <mesh position={[0, 0, -D / 2]} scale={[-1, 1, 1]} geometry={shape}><meshStandardMaterial color="#dfe6ec" roughness={0.5} side={THREE.DoubleSide} /></mesh>
      {/* folding doors on the front */}
      {[-1, 1].map((sd) => <mesh key={sd} geometry={shape} position={[sd * W2, 0, D / 2 + 0.15]} scale={[-sd * Math.max(0.07, 1 - s.doors * 0.93), 1, 1]} castShadow>
        <meshStandardMaterial color="#9fb3c8" metalness={0.5} roughness={0.4} side={THREE.DoubleSide} /></mesh>)}
      {/* interior */}
      <pointLight position={[0, 6, 0]} intensity={90} distance={30} color="#fff2d6" />
      <Box p={[-9.5, 0.55, -4]} a={[1.2, 1.0, 5]} color="#6b4a2f" rough={0.7} />
      <Box p={[-9.7, 1.4, -4]} a={[0.9, 0.7, 4.8]} color="#d62828" rough={0.35} />
      {[0, 1, 2].map((i) => <Cyl key={i} p={[9.2, 0.55, -6 + i * 1.2]} a={[0.45, 0.45, 1.1, 20]} color={i === 1 ? '#ffb300' : '#2f6fd1'} rough={0.4} metal={0.4} />)}
      {/* ground handling: dolly under the skids + tow bar + tug */}
      <group position={[0, 0, hz - z0]} visible={s.gear > 0.01 && s.hangar > 0.9 || s.gear > 0.01}>
        <Box p={[-1.15, 0.12, 0]} a={[0.22, 0.14, 3.2]} color="#ffc107" />
        <Box p={[1.15, 0.12, 0]} a={[0.22, 0.14, 3.2]} color="#ffc107" />
        {[[-1.15, -1.2], [-1.15, 1.2], [1.15, -1.2], [1.15, 1.2]].map((w, i) => <Cyl key={i} p={[w[0], 0.1, w[1]]} r={[0, 0, Math.PI / 2]} a={[0.1, 0.1, 0.2, 14]} color="#16181b" />)}
        <Box p={[0, 0.2, 2.1 - 5.8]} a={[0.1, 0.1, 3.0]} color="#d62828" />
        <group position={[0, 0, -6.5]}>
          <Box p={[0, 0.6, 0]} a={[1.6, 0.7, 2.2]} color="#ffb300" rough={0.35} />
          <Box p={[0, 1.15, 0.2]} a={[1.3, 0.5, 1.2]} m={M.glass} />
          {[[-0.85, -0.7], [0.85, -0.7], [-0.85, 0.7], [0.85, 0.7]].map((w, i) => <Cyl key={i} p={[w[0], 0.3, w[1]]} r={[0, 0, Math.PI / 2]} a={[0.3, 0.3, 0.25, 16]} color="#15171a" />)}
          <Sph p={[0, 1.5, 0.2]} s={[1, 0.5, 1]} a={[0.15]} color="#ffb300" emis="#ff8a00" ei={2.5 * s.beacon} shadow={false} />
        </group>
      </group>
    </group>
  );
};
