import React from 'react';
import {AbsoluteFill, useCurrentFrame, interpolate} from 'remotion';
import {Scene3D} from './Scene3D';
import {AudioTrack} from './audio/AudioTrack';
import {FPS, SCENES, DURATION_FRAMES} from './constants';
import {sceneIndex} from './timeline';

/** Chapter chip, kept inside the YouTube Shorts safe area (below the top UI, left of the right-hand buttons). */
const Chip: React.FC = () => {
  const f = useCurrentFrame(), t = f / FPS;
  const i = sceneIndex(t, SCENES), sc = SCENES[i];
  const local = t - sc.start;
  const o = interpolate(local, [0.2, 0.7, sc.end - sc.start - 0.5, sc.end - sc.start - 0.1], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', left: 56, top: 280, opacity: o, transform: `translateY(${(1 - o) * -14}px)`, display: 'flex', alignItems: 'center', gap: 16, padding: '14px 26px', borderRadius: 40, background: 'rgba(12,28,48,0.62)', color: '#fff', fontFamily: 'Arial, Helvetica, sans-serif', fontWeight: 800, fontSize: 38, letterSpacing: 2}}>
      <span style={{background: '#ffc107', color: '#10233a', borderRadius: 20, padding: '2px 16px'}}>{i + 1}/8</span>{sc.label}
    </div>
  );
};

const Fade: React.FC = () => {
  const f = useCurrentFrame();
  const o = Math.max(interpolate(f, [0, 12], [1, 0], {extrapolateRight: 'clamp'}), interpolate(f, [DURATION_FRAMES - 18, DURATION_FRAMES - 1], [0, 1], {extrapolateLeft: 'clamp'}));
  return <AbsoluteFill style={{background: '#000', opacity: o, pointerEvents: 'none'}} />;
};

export const Helicopter: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000'}}>
    <Scene3D />
    <Chip />
    <Fade />
    <AudioTrack />
  </AbsoluteFill>
);

/** Studio-only guide showing the Shorts UI zones. Never rendered into the final video. */
export const HelicopterSafeZones: React.FC = () => (
  <AbsoluteFill>
    <Helicopter />
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <div style={{position: 'absolute', top: 0, left: 0, right: 0, height: 250, background: 'rgba(255,0,0,0.25)'}} />
      <div style={{position: 'absolute', bottom: 0, left: 0, right: 0, height: 480, background: 'rgba(255,0,0,0.25)'}} />
      <div style={{position: 'absolute', top: 250, bottom: 480, right: 0, width: 120, background: 'rgba(255,160,0,0.25)'}} />
    </AbsoluteFill>
  </AbsoluteFill>
);
