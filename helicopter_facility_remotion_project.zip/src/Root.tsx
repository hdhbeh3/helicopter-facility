import React from 'react';
import {Composition} from 'remotion';
import {Helicopter, HelicopterSafeZones} from './Helicopter';
import {DURATION_FRAMES, FPS, HEIGHT, WIDTH} from './constants';

export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="Helicopter" component={Helicopter} durationInFrames={DURATION_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
    <Composition id="HelicopterSafeZones" component={HelicopterSafeZones} durationInFrames={DURATION_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
  </>
);
