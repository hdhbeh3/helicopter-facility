export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
/** Duration of the supplied voiceover (ffprobe: 65.04 s). The mp3 is used untouched. */
export const VO_DURATION_SEC = 65.04;
export const DURATION_FRAMES = Math.ceil(VO_DURATION_SEC * FPS); // 1952
export const DURATION_SEC = DURATION_FRAMES / FPS;

/**
 * 8 scenes. Boundaries sit on measured pauses in the voiceover (9.8, 17.05, 26.95, 33.1, 40.75, 47.15, 56.0 s).
 * NOTE: the transcript was not available, so the scene TOPICS are assumed from the project brief
 * (helicopter -> site/mud -> excavation+rebar -> concrete -> safety zone/windsock -> landing -> fuel -> hangar).
 * If your narration order differs, edit the numbers here + the keys in timeline.ts.
 */
export const SCENES = [
  {id: 'helicopter', label: 'THE HELICOPTER', start: 0, end: 9.8},
  {id: 'site', label: 'THE SITE', start: 9.8, end: 17.05},
  {id: 'excavation', label: 'EXCAVATE + REINFORCE', start: 17.05, end: 26.95},
  {id: 'concrete', label: 'CONCRETE PAD', start: 26.95, end: 33.1},
  {id: 'safety', label: 'SAFETY ZONE + WINDSOCK', start: 33.1, end: 40.75},
  {id: 'landing', label: 'LANDING', start: 40.75, end: 47.15},
  {id: 'fuel', label: 'FUEL STATION', start: 47.15, end: 56.0},
  {id: 'hangar', label: 'HANGAR', start: 56.0, end: DURATION_SEC},
] as const;

export const SAFE_SHIFT_PX = 115; // content centre -> middle of the Shorts safe area
export const MIX = {voiceover: 0.95, music: 1.0, sfx: 1.5, duckAmount: 0.45};
