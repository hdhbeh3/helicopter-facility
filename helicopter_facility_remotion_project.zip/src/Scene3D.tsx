import React, {useLayoutEffect, useMemo} from 'react';
import {useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {FPS, WIDTH, HEIGHT, SAFE_SHIFT_PX} from './constants';
import {cameraAt, getState, FOV} from './timeline';
import {lerp} from './math';
import {Sky, Clouds, Rain, Ground, PadWork, MixerTruck, SafetyZone, Windsock, Helicopter, FuelStation, Hangar} from './models';

/** Drives camera + sun from the timeline, then renders synchronously so every frame is deterministic. */
const Rig: React.FC<{clear: number}> = ({clear}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const {camera, gl, scene} = useThree();
  const cam = cameraAt(t);
  const c = camera as THREE.PerspectiveCamera;
  c.fov = FOV; c.aspect = WIDTH / HEIGHT; c.near = 0.3; c.far = 2000;
  c.position.set(...cam.pos);
  c.lookAt(...cam.target);
  c.setViewOffset(WIDTH, HEIGHT, 0, SAFE_SHIFT_PX, WIDTH, HEIGHT); // content centre -> middle of Shorts safe area
  c.updateProjectionMatrix();

  const sun = useMemo(() => new THREE.DirectionalLight('#fff1d6', 3), []);
  const tgt = useMemo(() => new THREE.Object3D(), []);
  const gx = THREE.MathUtils.clamp(cam.target[0], -30, 30), gz = THREE.MathUtils.clamp(cam.target[2], -40, 40);
  tgt.position.set(gx, 0, gz);
  sun.position.set(gx + 28, 46, gz + 30);
  sun.target = tgt;
  sun.intensity = lerp(0.9, 3.1, clear);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.04;
  Object.assign(sun.shadow.camera, {left: -34, right: 34, top: 34, bottom: -34, near: 1, far: 160});
  sun.shadow.camera.updateProjectionMatrix();

  useLayoutEffect(() => {
    gl.toneMapping = THREE.ACESFilmicToneMapping;
    gl.toneMappingExposure = 1.1;
    gl.shadowMap.enabled = true;
    gl.shadowMap.type = THREE.PCFSoftShadowMap;
  }, [gl]);
  useLayoutEffect(() => { gl.render(scene, camera); });
  return (<><primitive object={tgt} /><primitive object={sun} /></>);
};

const World: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const s = getState(t);
  const fog = new THREE.Color('#9aa6b2').lerp(new THREE.Color('#cfe8ff'), s.clear);
  return (
    <>
      <fog attach="fog" args={['#' + fog.getHexString(), 140, 520]} />
      <hemisphereLight args={['#d6ecff', '#6a8a45', lerp(0.55, 1.15, s.clear)]} />
      <ambientLight intensity={0.25} />
      <Sky clear={s.clear} />
      <Clouds t={t} clear={s.clear} />
      <Rain t={t} amt={s.rain} />
      <Ground s={s} />
      <PadWork s={s} />
      <MixerTruck s={s} />
      <SafetyZone t={t} s={s} />
      <Windsock t={t} s={s} />
      <FuelStation t={t} s={s} />
      <Hangar s={s} t={t} />
      <Helicopter t={t} />
      <Rig clear={s.clear} />
    </>
  );
};

export const Scene3D: React.FC = () => (
  <ThreeCanvas width={WIDTH} height={HEIGHT} shadows frameloop="demand" camera={{fov: FOV, near: 0.3, far: 2000, position: [0, 10, 30]}} gl={{antialias: true, preserveDrawingBuffer: true}}>
    <World />
  </ThreeCanvas>
);
